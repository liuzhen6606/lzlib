这是lzlib

安装方法：pip install lzlib

希望用的好！

联系邮箱：15936066606@163.com